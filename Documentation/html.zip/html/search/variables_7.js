var searchData=
[
  ['kappa_0',['KAPPA',['../d8/d42/structCahnHilliardInputParams.html#a4e9e16dc40733ab4c43ae1ef728e710f',1,'CahnHilliardInputParams']]],
  ['kernel_1',['kernel',['../d7/daf/global__vars_8h.html#a0a5832d47bf7e0c43db35fb93f58337f',1,'global_vars.h']]]
];
