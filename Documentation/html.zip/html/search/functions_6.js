var searchData=
[
  ['main_0',['main',['../d2/d37/getCLINFO_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;getCLINFO.c'],['../df/d24/mainfile_8c.html#a7a29781a20c5dd4153c3c1cecf0ff328',1,'main(int argc, char **args):&#160;mainfile.c']]]
];
