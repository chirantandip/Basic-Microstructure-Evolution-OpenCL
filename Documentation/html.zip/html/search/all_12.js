var searchData=
[
  ['write1dmattofile_0',['Write1DMatToFile',['../d1/d56/data__writing__funcs_8h.html#a768bc442d430a0c2990b19232046f3e3',1,'data_writing_funcs.h']]]
];
