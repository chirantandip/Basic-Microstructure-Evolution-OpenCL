var searchData=
[
  ['cahnhilliardkern_2ecl_0',['CahnHilliardKern.cl',['../d5/d24/CahnHilliardKern_8cl.html',1,'']]],
  ['cl_5futility_5ffuncs_2eh_1',['CL_utility_funcs.h',['../d3/d54/CL__utility__funcs_8h.html',1,'']]]
];
