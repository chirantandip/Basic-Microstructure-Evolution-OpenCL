var searchData=
[
  ['init1dfloatmatrix_0',['Init1DFloatMatrix',['../d1/dab/data__manip__funcs_8h.html#a06debc22a9baf6259f111bc69c34f0b9',1,'data_manip_funcs.h']]],
  ['init1dfloatmatrixwithboundary_1',['Init1DFloatMatrixWithBoundary',['../d1/dab/data__manip__funcs_8h.html#a5ce10a70fc99021c0280091cca4e5b09',1,'data_manip_funcs.h']]],
  ['initcahnhilliardbuffers_2',['initCahnHilliardBuffers',['../de/d7e/init__CL__buffers_8h.html#a3af5957d1cd8f24677bcbf880490cba0',1,'init_CL_buffers.h']]],
  ['initcentercircle_3',['InitCenterCircle',['../d1/dab/data__manip__funcs_8h.html#addf91393e896c901708c06c4cc0e2fd9',1,'data_manip_funcs.h']]],
  ['initcentersquare_4',['InitCenterSquare',['../d1/dab/data__manip__funcs_8h.html#a89bddb02cebe707669c9bf20154434e2',1,'data_manip_funcs.h']]],
  ['initcldatastructures_5',['initCLDataStructures',['../d3/d54/CL__utility__funcs_8h.html#a1462f9d3e01050cbe146202f5de01b85',1,'CL_utility_funcs.h']]],
  ['initdiffusionbuffers_6',['initDiffusionBuffers',['../de/d7e/init__CL__buffers_8h.html#a808374b9756967cbfdba8c91205ac94a',1,'init_CL_buffers.h']]],
  ['initkobayashianisobuffers_7',['initKobayashiAnisoBuffers',['../de/d7e/init__CL__buffers_8h.html#a8bb27aeb9084ce0b675c0372872b15ed',1,'init_CL_buffers.h']]],
  ['initkobayashiisobuffers_8',['initKobayashiIsoBuffers',['../de/d7e/init__CL__buffers_8h.html#a684b38a7574c3fe2ed27a72ab1cf1401',1,'init_CL_buffers.h']]],
  ['iteratecahnhilliardkernel_9',['iterateCahnHilliardKernel',['../d4/dd3/iterate__kernels_8h.html#aae6b4cd59675af00f0ec57f318fe1ec5',1,'iterate_kernels.h']]],
  ['iteratediffusionkernel_10',['iterateDiffusionKernel',['../d4/dd3/iterate__kernels_8h.html#a088bba2577a14c612dcc2759e645b030',1,'iterate_kernels.h']]],
  ['iteratekobayashianisokernel_11',['iterateKobayashiAnisoKernel',['../d4/dd3/iterate__kernels_8h.html#a76a4479b99815c3afe415391d7fdf30a',1,'iterate_kernels.h']]],
  ['iteratekobayashiisokernel_12',['iterateKobayashiIsoKernel',['../d4/dd3/iterate__kernels_8h.html#ad6d0347b60e66b99c72f2afc5f43135f',1,'iterate_kernels.h']]]
];
