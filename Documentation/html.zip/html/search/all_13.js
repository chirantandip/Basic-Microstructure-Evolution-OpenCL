var searchData=
[
  ['write1dmattofile_0',['Write1DMatToFile',['../d1/d56/data__writing__funcs_8h.html#a81461a3fa5ba07e960793edffb148377',1,'data_writing_funcs.h']]]
];
