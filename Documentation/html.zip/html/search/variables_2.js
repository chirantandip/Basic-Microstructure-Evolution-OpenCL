var searchData=
[
  ['delta_0',['DELTA',['../dd/da7/structKobAnisoInputParams.html#ac186788bf197054f4625162bfc90357f',1,'KobAnisoInputParams']]],
  ['devices_1',['devices',['../d7/daf/global__vars_8h.html#a097da19e89bd59ea7408d35fac4907ec',1,'global_vars.h']]],
  ['devid_2',['devID',['../d7/daf/global__vars_8h.html#a007e792924b73483e55e23e11b7f3eb1',1,'global_vars.h']]],
  ['diff_5fcoeff_3',['DIFF_COEFF',['../d2/d9c/structDiffusionInputParams.html#a076966a27284e5aa20bb92ba0b89c89e',1,'DiffusionInputParams']]],
  ['dt_4',['DT',['../d7/daf/global__vars_8h.html#a4a437d27ce9d2c00fd6558c4903e9910',1,'global_vars.h']]],
  ['dx_5',['DX',['../d7/daf/global__vars_8h.html#a7d53156118d387b4a1b713a6e51794f1',1,'global_vars.h']]]
];
