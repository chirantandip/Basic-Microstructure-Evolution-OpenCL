var searchData=
[
  ['diffusiondatabuffers_0',['DiffusionDataBuffers',['../d3/dbd/structDiffusionDataBuffers.html',1,'']]],
  ['diffusioninputparams_1',['DiffusionInputParams',['../d2/d9c/structDiffusionInputParams.html',1,'']]]
];
