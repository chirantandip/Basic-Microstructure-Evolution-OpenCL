var searchData=
[
  ['l_5fheat_0',['L_HEAT',['../dd/da7/structKobAnisoInputParams.html#ab8ed75ce4ab20e444bc2f45261091e53',1,'KobAnisoInputParams::L_HEAT()'],['../db/d0e/structKobIsoInputParams.html#aafd61f229da01503f05df13202609a34',1,'KobIsoInputParams::L_HEAT()']]]
];
