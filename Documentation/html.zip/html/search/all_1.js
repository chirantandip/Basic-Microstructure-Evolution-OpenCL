var searchData=
[
  ['cahnhilliarddatabuffers_0',['CahnHilliardDataBuffers',['../df/d96/structCahnHilliardDataBuffers.html',1,'']]],
  ['cahnhilliardevolutinstep_1',['CahnHilliardEvolutinStep',['../d4/dd3/iterate__kernels_8h.html#a772f4d65c2d904158426e0fc06a736ab',1,'iterate_kernels.h']]],
  ['cahnhilliardinputparams_2',['CahnHilliardInputParams',['../d8/d42/structCahnHilliardInputParams.html',1,'']]],
  ['cahnhilliardkern_2ecl_3',['CahnHilliardKern.cl',['../d5/d24/CahnHilliardKern_8cl.html',1,'']]],
  ['check_5fneighbors_4',['check_neighbors',['../df/df2/KobayashiAnisoKern_8cl.html#acfa7e78b38f406514704afbd2e2d0c3c',1,'check_neighbors(__global float *PH, int x, int y):&#160;KobayashiAnisoKern.cl'],['../d2/dda/KobayashiIsoKern_8cl.html#acfa7e78b38f406514704afbd2e2d0c3c',1,'check_neighbors(__global float *PH, int x, int y):&#160;KobayashiIsoKern.cl']]],
  ['chinnerevol_5',['CHInnerEvol',['../d5/d24/CahnHilliardKern_8cl.html#a1fad88689ba23a97c1f6681e743f5713',1,'CahnHilliardKern.cl']]],
  ['chouterevol_6',['CHOuterEvol',['../d5/d24/CahnHilliardKern_8cl.html#aaff07eaafa02ff46ac65b6525baad7cc',1,'CahnHilliardKern.cl']]],
  ['cl_5futility_5ffuncs_2eh_7',['CL_utility_funcs.h',['../d3/d54/CL__utility__funcs_8h.html',1,'']]],
  ['context_8',['context',['../d7/daf/global__vars_8h.html#a7afda8b03e51380bc7cdb908a95ae73a',1,'global_vars.h']]]
];
