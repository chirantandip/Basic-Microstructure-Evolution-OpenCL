var searchData=
[
  ['alpha_0',['ALPHA',['../dd/da7/structKobAnisoInputParams.html#a99120d552362f3e317ae15d0aed26ebe',1,'KobAnisoInputParams::ALPHA()'],['../db/d0e/structKobIsoInputParams.html#a8415d27c3b0a12b4c9442812deb5177d',1,'KobIsoInputParams::ALPHA()']]]
];
