var searchData=
[
  ['phase1_0',['PHASE1',['../d3/dbd/structDiffusionDataBuffers.html#a58f9d2c51dcf3aa646bdf97199a6dbb5',1,'DiffusionDataBuffers::PHASE1()'],['../df/d96/structCahnHilliardDataBuffers.html#a75b7819deeb9ce5231bd3207acd10e63',1,'CahnHilliardDataBuffers::PHASE1()'],['../d5/d1b/structKobAnisoDataBuffers.html#a8ee9155f566a7349a02edbe18ff80a17',1,'KobAnisoDataBuffers::PHASE1()'],['../d9/d09/structKobIsoDataBuffers.html#aa384a0bec6b15b47d25a23715ae20d26',1,'KobIsoDataBuffers::PHASE1()']]],
  ['phase1buff_1',['PHASE1buff',['../d3/dbd/structDiffusionDataBuffers.html#acfc3ff3da0f1c84661f821bd17c66470',1,'DiffusionDataBuffers::PHASE1buff()'],['../df/d96/structCahnHilliardDataBuffers.html#ade00bdc5c2865af28fdc722ce02a31cd',1,'CahnHilliardDataBuffers::PHASE1buff()'],['../d5/d1b/structKobAnisoDataBuffers.html#a9143efe8f74f6da90de513b0cc5763d2',1,'KobAnisoDataBuffers::PHASE1buff()'],['../d9/d09/structKobIsoDataBuffers.html#adacc37da02f09b0710debdfe546a6fa1',1,'KobIsoDataBuffers::PHASE1buff()']]],
  ['phase_5fl_2',['PHASE_L',['../db/d0e/structKobIsoInputParams.html#af4f08ccf5973c6362795d45666e6deb9',1,'KobIsoInputParams']]],
  ['platform_3',['platform',['../d7/daf/global__vars_8h.html#a8b3cf9023524a418138aee4add72db44',1,'global_vars.h']]],
  ['platid_4',['platID',['../d7/daf/global__vars_8h.html#a585f2f40b1372667c8b16b85dde478c9',1,'global_vars.h']]]
];
