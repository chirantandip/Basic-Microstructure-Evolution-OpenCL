var searchData=
[
  ['size_0',['SIZE',['../d7/daf/global__vars_8h.html#a5e29d26043fe3e33243366271f039d6f',1,'global_vars.h']]]
];
