var searchData=
[
  ['data_5fmanip_5ffuncs_2eh_0',['data_manip_funcs.h',['../d1/dab/data__manip__funcs_8h.html',1,'']]],
  ['data_5fwriting_5ffuncs_2eh_1',['data_writing_funcs.h',['../d1/d56/data__writing__funcs_8h.html',1,'']]],
  ['delta_2',['DELTA',['../dd/da7/structKobAnisoInputParams.html#ac186788bf197054f4625162bfc90357f',1,'KobAnisoInputParams']]],
  ['devices_3',['devices',['../d7/daf/global__vars_8h.html#a097da19e89bd59ea7408d35fac4907ec',1,'global_vars.h']]],
  ['devid_4',['devID',['../d7/daf/global__vars_8h.html#a007e792924b73483e55e23e11b7f3eb1',1,'global_vars.h']]],
  ['diff_5fcoeff_5',['DIFF_COEFF',['../d2/d9c/structDiffusionInputParams.html#a076966a27284e5aa20bb92ba0b89c89e',1,'DiffusionInputParams']]],
  ['diffusiondatabuffers_6',['DiffusionDataBuffers',['../d3/dbd/structDiffusionDataBuffers.html',1,'']]],
  ['diffusionevolutionstep_7',['DiffusionEvolutionStep',['../d4/dd3/iterate__kernels_8h.html#ad8656dc95b2bc364bb473b606b11043f',1,'iterate_kernels.h']]],
  ['diffusioninputparams_8',['DiffusionInputParams',['../d2/d9c/structDiffusionInputParams.html',1,'']]],
  ['diffusionkern_2ecl_9',['DiffusionKern.cl',['../de/de9/DiffusionKern_8cl.html',1,'']]],
  ['dt_10',['DT',['../d7/daf/global__vars_8h.html#a4a437d27ce9d2c00fd6558c4903e9910',1,'global_vars.h']]],
  ['dx_11',['DX',['../d7/daf/global__vars_8h.html#a7d53156118d387b4a1b713a6e51794f1',1,'global_vars.h']]]
];
