var searchData=
[
  ['context_0',['context',['../d7/daf/global__vars_8h.html#a7afda8b03e51380bc7cdb908a95ae73a',1,'global_vars.h']]]
];
