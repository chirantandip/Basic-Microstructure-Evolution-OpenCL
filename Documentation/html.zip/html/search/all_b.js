var searchData=
[
  ['noise_5famp_0',['NOISE_AMP',['../d8/d42/structCahnHilliardInputParams.html#acadced448d29e0be8a1cd0ca7c08a5be',1,'CahnHilliardInputParams::NOISE_AMP()'],['../dd/da7/structKobAnisoInputParams.html#a16044b984385cf1f70b2b5d9cd189610',1,'KobAnisoInputParams::NOISE_AMP()'],['../db/d0e/structKobIsoInputParams.html#a63feed0e3c8cb0fc396d0141b5b69c26',1,'KobIsoInputParams::NOISE_AMP()']]],
  ['nsave_1',['NSAVE',['../d7/daf/global__vars_8h.html#a63dc0b709640aca75d325c89d11e24f7',1,'global_vars.h']]],
  ['numdevices_2',['numDevices',['../d7/daf/global__vars_8h.html#aa64935ea0ea2149a502554ee29845f5b',1,'global_vars.h']]]
];
