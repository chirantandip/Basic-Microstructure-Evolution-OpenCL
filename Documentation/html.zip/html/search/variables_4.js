var searchData=
[
  ['gamma_0',['GAMMA',['../dd/da7/structKobAnisoInputParams.html#a1484d2ec631fef9b24cf6c8e9cc5248c',1,'KobAnisoInputParams::GAMMA()'],['../db/d0e/structKobIsoInputParams.html#a581f58cad701414b3a7e5ede08cefef3',1,'KobIsoInputParams::GAMMA()']]]
];
