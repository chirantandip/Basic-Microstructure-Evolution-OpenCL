var searchData=
[
  ['cahnhilliarddatabuffers_0',['CahnHilliardDataBuffers',['../df/d96/structCahnHilliardDataBuffers.html',1,'']]],
  ['cahnhilliardinputparams_1',['CahnHilliardInputParams',['../d8/d42/structCahnHilliardInputParams.html',1,'']]]
];
