var searchData=
[
  ['getclinfo_2ec_0',['getCLINFO.c',['../d2/d37/getCLINFO_8c.html',1,'']]],
  ['global_5fvars_2eh_1',['global_vars.h',['../d7/daf/global__vars_8h.html',1,'']]]
];
