var searchData=
[
  ['gamma_0',['GAMMA',['../dd/da7/structKobAnisoInputParams.html#a1484d2ec631fef9b24cf6c8e9cc5248c',1,'KobAnisoInputParams::GAMMA()'],['../db/d0e/structKobIsoInputParams.html#a581f58cad701414b3a7e5ede08cefef3',1,'KobIsoInputParams::GAMMA()']]],
  ['get_5fdepsdtheta_1',['get_DepsDtheta',['../df/df2/KobayashiAnisoKern_8cl.html#a9199fc5592a26e705a25f1d439305363',1,'KobayashiAnisoKern.cl']]],
  ['get_5fdpdx_2',['get_dPdX',['../df/df2/KobayashiAnisoKern_8cl.html#a689affabd487dac84d739a80c849d450',1,'KobayashiAnisoKern.cl']]],
  ['get_5fdpdy_3',['get_dPdY',['../df/df2/KobayashiAnisoKern_8cl.html#ada3b38e51905511672e83b2b9a88a69e',1,'KobayashiAnisoKern.cl']]],
  ['get_5fepsdepsdtheta_4',['get_epsDepsDtheta',['../df/df2/KobayashiAnisoKern_8cl.html#ad04decdddcfcbe62bbd8f73bd6cfd75e',1,'KobayashiAnisoKern.cl']]],
  ['get_5fepsilon_5',['get_epsilon',['../df/df2/KobayashiAnisoKern_8cl.html#ae9fa339de80cfcc2704357694b3b420c',1,'KobayashiAnisoKern.cl']]],
  ['get_5fphase_5flaplacian_6',['get_phase_laplacian',['../df/df2/KobayashiAnisoKern_8cl.html#aca1807afd6acf108d10a67f6df9f67ed',1,'get_phase_laplacian(__global float *PH, int x, int y):&#160;KobayashiAnisoKern.cl'],['../d2/dda/KobayashiIsoKern_8cl.html#aca1807afd6acf108d10a67f6df9f67ed',1,'get_phase_laplacian(__global float *PH, int x, int y):&#160;KobayashiIsoKern.cl']]],
  ['get_5ftemp_5flaplacian_7',['get_temp_laplacian',['../df/df2/KobayashiAnisoKern_8cl.html#a9cb6ac4bda8936a2daabf72df95f0f42',1,'get_temp_laplacian(__global float *TEMP, int x, int y):&#160;KobayashiAnisoKern.cl'],['../d2/dda/KobayashiIsoKern_8cl.html#a9cb6ac4bda8936a2daabf72df95f0f42',1,'get_temp_laplacian(__global float *TEMP, int x, int y):&#160;KobayashiIsoKern.cl']]],
  ['get_5ftheta_8',['get_theta',['../df/df2/KobayashiAnisoKern_8cl.html#aac8f34b5a31f3628c69d2c77eec69813',1,'KobayashiAnisoKern.cl']]],
  ['getclinfo_2ec_9',['getCLINFO.c',['../d2/d37/getCLINFO_8c.html',1,'']]],
  ['getdeviceinfo_10',['getDeviceInfo',['../d2/d37/getCLINFO_8c.html#a96e7e14174af7c77813bae400c6164f4',1,'getCLINFO.c']]],
  ['geteventexectime_11',['GetEventExecTime',['../d3/d54/CL__utility__funcs_8h.html#a605448c7febf6b9c3989424427a0105b',1,'CL_utility_funcs.h']]],
  ['getkernelfromfile_12',['getKernelFromFile',['../d5/d9c/file__to__program_8h.html#aed0c1268c2130c0811d2d71457c4c7a8',1,'file_to_program.h']]],
  ['getoptimumwgsize_13',['GetOptimumWGSize',['../d3/d54/CL__utility__funcs_8h.html#a341203a0daef790b448d1d988352f052',1,'CL_utility_funcs.h']]],
  ['getplatforminfo_14',['getPlatformInfo',['../d2/d37/getCLINFO_8c.html#ad23c81e1e7856c167610f30eccddc37b',1,'getCLINFO.c']]],
  ['global_5fvars_2eh_15',['global_vars.h',['../d7/daf/global__vars_8h.html',1,'']]]
];
