var searchData=
[
  ['data_5fmanip_5ffuncs_2eh_0',['data_manip_funcs.h',['../d1/dab/data__manip__funcs_8h.html',1,'']]],
  ['data_5fwriting_5ffuncs_2eh_1',['data_writing_funcs.h',['../d1/d56/data__writing__funcs_8h.html',1,'']]],
  ['diffusionkern_2ecl_2',['DiffusionKern.cl',['../de/de9/DiffusionKern_8cl.html',1,'']]]
];
